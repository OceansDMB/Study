// if 조건문의 사용법을 예제로 설명해보시오.
// 이 문제는 자바의 if 조건문을 사용할 수 있는지에 대해서 묻는 문제이다.


public class Java100_if_Basic001 {
	public static void main(String[] args) {
		
		// [1] : 변수 선언
		int kor=80, eng=90, math=100;
		
		// [2] : if 조건문만 사용하기
		if ( kor >= 80 )
			System.out.println( "당신의 국어 점수는 B 학점입니다." );
		
		System.out.println( "학점이 안나왔다면 80점이 안되서입니다." );
		
	}
}











