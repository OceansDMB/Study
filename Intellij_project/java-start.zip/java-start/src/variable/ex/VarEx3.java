package variable.ex;

public class VarEx3 {
    public static void main(String[] args) {
        long longVar = 10000000000L;
        System.out.println(longVar);

        boolean booleanVar = true;
        System.out.println(booleanVar);
    }
}
